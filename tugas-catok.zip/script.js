/* General Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
    color: #333;
}

/* Navbar Styles */
.navbar {
    background-color: #4CAF50;
    padding: 10px;
    text-align: center;
}

.navbar ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.navbar ul li {
    display: inline;
    margin: 0 15px;
}

.navbar ul li a {
    color: white;
    text-decoration: none;
    font-size: 18px;
    transition: color 0.3s;
}

.navbar ul li a:hover {
    color: #ffeb3b;
}

/* Container Styles */
.container {
    width: 80%;
    margin: 0 auto;
    padding: 20px;
}

/* Profile Section */
.profile {
    display: flex;
    align-items: center;
    margin-bottom: 30px;
}

.profile-image {
    border-radius: 50%;
    width: 150px;
    height: 150px;
    object-fit: cover;
    margin-right: 20px;
}

.profile-info h1, .profile-info h2, .profile-info h3 {
    margin: 5px 0;
}

.profile-info a {
    color: #4CAF50;
    text-decoration: none;
}

.profile-info a:hover {
    text-decoration: underline;
}

/* Section Styles */
section {
    margin-bottom: 30px;
}

h3 {
    color: #4CAF50;
    border-bottom: 2px solid #4CAF50;
    padding-bottom: 5px;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

table th, table td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
}

table th {
    background-color: #4CAF50;
    color: white;
}

table tr:nth-child(even) {
    background-color: #f2f2f2;
}

/* Lists */
ul {
    list-style-type: square;
    padding-left: 20px;
}

ul li {
    margin: 5px 0;
}
